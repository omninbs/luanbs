local M = {}

M.read = require("parser")
M.write = require("writer")

return M
